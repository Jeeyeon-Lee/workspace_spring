package com.example.demo.logic;

import org.springframework.stereotype.Service;

@Service
public class TestLogic {

}
